#pragma once

#include "nvim/eval/typval_defs.h"  // IWYU pragma: keep

extern char *e_list_index_out_of_range_nr;

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "eval/executor.h.generated.h"
#endif
