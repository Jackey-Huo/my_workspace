local hello = require('testluaplugin/hello').hello

return {
    hello = hello
}
