// This file exists to create a nice static or shared library via cmake
// but can otherwise be omitted if you prefer to compile tinyply
// directly into your own project.
#define TINYPLY_IMPLEMENTATION
#include <cilantro/3rd_party/tinyply/tinyply.h>
