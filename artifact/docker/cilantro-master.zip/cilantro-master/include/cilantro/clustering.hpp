#pragma once

#include <cilantro/clustering/clustering_base.hpp>
#include <cilantro/clustering/connected_component_extraction.hpp>
#include <cilantro/clustering/kmeans.hpp>
#include <cilantro/clustering/mean_shift.hpp>
#include <cilantro/clustering/spectral_clustering.hpp>
